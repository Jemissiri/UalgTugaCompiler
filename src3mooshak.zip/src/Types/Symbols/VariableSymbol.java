package Types.Symbols;

import Types.*;

public class VariableSymbol extends Symbol
{
    public VariableSymbol(String name, TugaTypes type) { super(name, type); }
}
