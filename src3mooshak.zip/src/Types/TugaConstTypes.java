package Types;

public enum TugaConstTypes
{
    DOUBLE,
    STRING,
}
